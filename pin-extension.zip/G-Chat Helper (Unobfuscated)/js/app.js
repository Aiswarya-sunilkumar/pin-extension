
  
const initControls = () => {
    $('body')['on']('mouseover', 'div[jscontroller="LKRZMd"]', function(_0x2319x2) {
    
        if ($(_0x2319x2['currentTarget'])['parent']()['siblings']('div.HO0hcf')['children']('div')['children']('.pin-btn')['length'] == 0) {
            var _0x2319x3 = $('<div class="U26fgb mUbCce fKz7Od OniOhf cF0Lnd n8aqX PFn4wd M9Bg4d pin-btn"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 1920 1920" style="margin-top:4px; margin-left:4px;"><path fill="#8c8c8c" stroke="#8c8c8c" d="m692.08 851.622 343.003 343.002c53.309 53.308 82.673 124.235 82.673 199.567 0 75.445-29.364 146.372-82.673 199.68l-16.49 16.49-742.361-742.25 16.489-16.49c106.73-106.842 292.743-106.842 399.36 0Zm340.18-387.389 390.437 390.438-286.193 286.193c-7.34-8.584-13.44-18.07-21.571-26.09L771.93 771.773c-4.752-4.819-10.019-8.805-15.309-12.757l-1.983-1.482c-2.974-2.225-5.936-4.471-8.797-6.88l286.419-286.42Zm102.776-304.489 592.15 592.038-83.914 83.915c-22.024 22.023-57.826 22.023-79.85 0l-20.442-20.442c-.226-.226-.226-.452-.452-.678-.226-.113-.452-.113-.565-.339L1072.806 345.08c-.226-.225-.34-.564-.565-.79-.226-.226-.565-.339-.79-.452l-20.33-20.33c-22.024-22.023-22.024-57.938 0-79.962l83.915-83.802Zm0-159.699L971.272 163.697c-59.295 59.294-62.344 150.776-15.022 216.847L658.876 677.918c-4.066 3.953-6.437 8.81-9.035 13.553-144.565-60.085-322.899-33.656-436.97 80.301l-96.338 96.34 411.106 411.105-511.06 511.059c-22.136 22.023-22.136 57.826 0 79.85 10.956 11.067 25.413 16.602 39.869 16.602s28.913-5.535 39.981-16.603l511.059-511.059 411.106 410.993 96.339-96.339c74.654-74.54 115.764-173.816 115.764-279.529 0-55.115-11.745-108.31-33.091-157.327 2.597-1.92 5.647-3.05 8.018-5.421l300.763-300.763c29.365 20.895 62.456 34.448 96.903 34.448 43.37 0 86.852-16.603 119.83-49.582l163.766-163.764L1135.036.045Z"/></svg></div>');
           // var _0x2319x3 = $('<div class="U26fgb mUbCce fKz7Od OniOhf cF0Lnd n8aqX PFn4wd M9Bg4d pin-btn"><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0 0 24 24"><path d="M 6.0097656 2 C 4.9143111 2 4.0097656 2.9025988 4.0097656 3.9980469 L 4 22 L 12 19 L 20 22 L 20 20.556641 L 20 4 C 20 2.9069372 19.093063 2 18 2 L 6.0097656 2 z M 6.0097656 4 L 18 4 L 18 19.113281 L 12 16.863281 L 6.0019531 19.113281 L 6.0097656 4 z"></path></svg></div>');
            _0x2319x3['on']('click', function() {
                let _0x2319x5 = $(_0x2319x2['currentTarget'])['parents']('.iKCcE')['siblings']('.NGoCob.SAS2Ne')['find']('[data-member-id]')['data']('name');
                let _0x2319x6 = document['querySelector']('span.cAW0Vc.xIGxrd');
                let _0x2319x7 = document['querySelector']('.dKv0S.mXMold');
                const _0x2319x8 = document['querySelector']('.FvYVyf');
                const _0x2319x9 = _0x2319x8['getAttribute']('data-absolute-timestamp');
                const _0x2319xa = new Date(parseInt(_0x2319x9));
                const _0x2319xb = `${''}${_0x2319xa['getMonth']()+ 1}${'/'}${_0x2319xa['getDate']()}${'/'}${_0x2319xa['getFullYear']().toString()['substr'](-2)}${''}`;
                let _0x2319xc = $(_0x2319x2['currentTarget'])['html']();
                let _0x2319xd = removeTags(_0x2319xc);
                const _0x2319xe = {
                    name: _0x2319x5,
                    message: _0x2319xd,
                    date: _0x2319xb
                };
                if (_0x2319x6) {
                    let _0x2319xf = _0x2319x6['getAttribute']('data-hovercard-id');
                    localStorage['setItem'](_0x2319xf, JSON['stringify'](_0x2319xe));
                    let _0x2319x10 = localStorage['getItem'](_0x2319xf);
                    displayMessage(_0x2319xf)
                };
                if (_0x2319x7) {
                    let _0x2319x11 = _0x2319x7['getAttribute']('data-group-id');
                    localStorage['setItem'](_0x2319x11, JSON['stringify'](_0x2319xe));
                    displayMessage(_0x2319x11)
                }
            });
            $(_0x2319x2['currentTarget'])['parent']()['siblings']('div.HO0hcf')['children']('div')['append'](_0x2319x3)
        }
    })
};

function removeTags(_0x2319x13) {
    if ((_0x2319x13 === null) || (_0x2319x13 === '')) {
        return false
    } else {
        _0x2319x13 = _0x2319x13.toString()
    };
    return _0x2319x13['replace'](/(<([^>]+)>)/ig, '')
}

function displayMessage(_0x2319xf) {
    let _0x2319x10 = localStorage['getItem'](_0x2319xf);    
    var _0x2319x15 = JSON['parse'](_0x2319x10);
    let _0x2319x5 = _0x2319x15['name'];
    let _0x2319x16 = _0x2319x15['message'];
    let _0x2319x17 = _0x2319x15['date'];
    if (_0x2319x10) {
        let _0x2319x18 = document['querySelector']('.vIO7af');
        let _0x2319x19 = document['querySelector']('.message_data');
        if (_0x2319x19) {
            _0x2319x19['remove']()
        };
        let _0x2319x1a = document['createElement']('div');
        _0x2319x1a['classList']['add']('message_data');
        _0x2319x1a['innerHTML'] = `${'<span button class="unpin_button"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24"  style="margin-top:4px;  margin-left:4px fill-rule="nonzero" stroke-linejoin="round" stroke-miterlimit="2" clip-rule="evenodd"><path d="M555.83,469.245L551.293,464.707C550.903,464.317 550.903,463.683 551.293,463.293C551.683,462.903 552.317,462.903 552.707,463.293L568.694,479.28C569.085,479.671 569.085,480.304 568.694,480.694C568.304,481.085 567.671,481.085 567.28,480.694L562.586,476L561,476L561,481C561,481.552 560.552,482 560,482C559.448,482 559,481.552 559,481L559,476L555,476C554.448,476 554,475.552 554,475C554,475 554,473.255 554,472.07C554,471.067 554.501,470.131 555.336,469.574L555.83,469.245ZM557.273,470.687L560.586,474L556,474C556,474 556,472.07 556,472.07C556,471.736 556.167,471.424 556.445,471.238L557.273,470.687ZM555.534,463.291C556.075,462.511 556.978,462 558,462L562,462C563.657,462 565,463.343 565,465C565,466.306 564.165,467.418 563,467.829L563,468.465C563,468.465 564.664,469.574 564.664,469.574C565.499,470.131 566,471.067 566,472.07L566,473.757L561,468.757L561,467C561,466.448 561.448,466 562,466L562,466C562.552,466 563,465.552 563,465C563,464.448 562.552,464 562,464C562,464 558,464 558,464C557.523,464 557.124,464.334 557.024,464.781L555.534,463.291Z" transform="translate(-548 -460)"/></svg></span><span class="message_name">'}${_0x2319x5}${' : </span> <span class="message_text_short">'}${_0x2319x16['substring'](0,50)}${'...</span> <span class="message_text_long">'}${_0x2319x16}${'</span><span class="message_date">'}${_0x2319x17}${'</span>'}`;
        _0x2319x1a['setAttribute']('data-message', _0x2319x10);
        _0x2319x18['appendChild'](_0x2319x1a);
        let _0x2319x1b = document['createElement']('button');
        _0x2319x1b['classList']['add']('expand_button');
        _0x2319x1b['innerText'] = 'Read more';
        _0x2319x1a['appendChild'](_0x2319x1b);
        let _0x2319x1c = _0x2319x1a['querySelector']('.message_text_short');
        let _0x2319x1d = _0x2319x1a['querySelector']('.message_text_long');
        _0x2319x1d['style']['display'] = 'none';
        _0x2319x1b['addEventListener']('click', function() {
            if (_0x2319x1d['style']['display'] === 'none') {
                _0x2319x1c['style']['display'] = 'none';
                _0x2319x1d['style']['display'] = 'inline';
                _0x2319x1b['innerText'] = 'Read less'
            } else {
                _0x2319x1c['style']['display'] = 'inline';
                _0x2319x1d['style']['display'] = 'none';
                _0x2319x1b['innerText'] = 'Read more'
            }
        });
        let _0x2319x1e = _0x2319x1a['querySelector']('.unpin_button');
        _0x2319x1e['addEventListener']('click', function() {
            localStorage['removeItem'](_0x2319xf);
            _0x2319x1a['remove']()
        })
    }
}
const loadPinnedMessage = () => {
    let _0x2319x6 = document['querySelector']('span.cAW0Vc.xIGxrd');
    if (_0x2319x6) {
        let _0x2319xf = _0x2319x6['getAttribute']('data-hovercard-id');
        displayMessage(_0x2319xf)
    } else {
        setTimeout(function() {
            loadPinnedMessage()
        }, 1000)
    }
};
const loadPinnedSpaceMessage = () => {
    let _0x2319x6 = document['querySelector']('.dKv0S.mXMold');
    if (_0x2319x6) {
        let _0x2319x11 = _0x2319x6['getAttribute']('data-group-id');
        displayMessage(_0x2319x11)
    } else {
        setTimeout(function() {
            loadPinnedSpaceMessage()
        }, 1000)
    }
};
const init = async () => {
    initControls();
    loadPinnedMessage();
    loadPinnedSpaceMessage()
};
export const app = async () => {
    await init()
}